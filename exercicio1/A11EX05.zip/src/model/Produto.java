package model;
public class Produto {
 private int codigo,fabricante;private String nome,modelo,cor;private double peso,valor;
 public Produto(){} public Produto(int codigo,String nome,String modelo,String cor,double peso,double valor,int fabricante){this.codigo=codigo;this.nome=nome;this.modelo=modelo;this.cor=cor;this.peso=peso;this.valor=valor;this.fabricante=fabricante;}
 public Produto(String nome,String modelo,String cor,double peso,double valor,int fabricante){this(0,nome,modelo,cor,peso,valor,fabricante);}
 public int getCodigo(){return codigo;}public void setCodigo(int v){codigo=v;}public String getNome(){return nome;}public void setNome(String v){nome=v;}public String getModelo(){return modelo;}public void setModelo(String v){modelo=v;}public String getCor(){return cor;}public void setCor(String v){cor=v;}public double getPeso(){return peso;}public void setPeso(double v){peso=v;}public double getValor(){return valor;}public void setValor(double v){valor=v;}public int getFabricante(){return fabricante;}public void setFabricante(int v){fabricante=v;}
 public String toString(){return "Código: "+codigo+" | "+nome+" | Modelo: "+modelo+" | Cor: "+cor+" | Peso: "+peso+" | Valor: "+valor+" | Fabricante: "+fabricante;}
}