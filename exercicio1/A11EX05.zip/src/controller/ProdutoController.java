package controller;
import dao.ProdutoDAO;import model.Produto;import java.util.List;
public class ProdutoController{private final ProdutoDAO dao=new ProdutoDAO();public void inserir(Produto p){dao.inserir(p);}public void alterar(Produto p){dao.alterar(p);}public void excluir(int i){dao.excluir(i);}public List<Produto> buscar(){return dao.buscar();}}
