package view;
import controller.ProdutoController;import model.Produto;import java.util.*;
public class ProdutoView{
public static void main(String[]a){Scanner s=new Scanner(System.in);ProdutoController c=new ProdutoController();int op;
do{System.out.println("\n=== A11EX05 - PRODUTO ===\n1-Cadastrar\n2-Listar\n3-Alterar\n4-Excluir\n0-Sair");op=s.nextInt();s.nextLine();
switch(op){case 1:System.out.print("Nome: ");String n=s.nextLine();System.out.print("Modelo: ");String m=s.nextLine();System.out.print("Cor: ");String cor=s.nextLine();System.out.print("Peso: ");double p=s.nextDouble();System.out.print("Valor: ");double v=s.nextDouble();System.out.print("Código fabricante: ");int f=s.nextInt();s.nextLine();c.inserir(new Produto(n,m,cor,p,v,f));break;
case 2:c.buscar().forEach(System.out::println);break;
case 3:System.out.print("Código: ");int id=s.nextInt();s.nextLine();System.out.print("Nome: ");n=s.nextLine();System.out.print("Modelo: ");m=s.nextLine();System.out.print("Cor: ");cor=s.nextLine();System.out.print("Peso: ");p=s.nextDouble();System.out.print("Valor: ");v=s.nextDouble();System.out.print("Fabricante: ");f=s.nextInt();s.nextLine();c.alterar(new Produto(id,n,m,cor,p,v,f));break;
case 4:System.out.print("Código: ");c.excluir(s.nextInt());s.nextLine();break;}}while(op!=0);s.close();}}
