package model;
public class Fabricante {
 private int codigo; private String nome;
 public Fabricante(){} public Fabricante(int codigo,String nome){this.codigo=codigo;this.nome=nome;} public Fabricante(String nome){this.nome=nome;}
 public int getCodigo(){return codigo;} public void setCodigo(int v){codigo=v;}
 public String getNome(){return nome;} public void setNome(String v){nome=v;}
 public String toString(){return "Código: "+codigo+" | Nome: "+nome;}
}