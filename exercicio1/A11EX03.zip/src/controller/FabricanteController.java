package controller;
import dao.FabricanteDAO; import model.Fabricante; import java.util.List;
public class FabricanteController {private final FabricanteDAO dao=new FabricanteDAO(); public void inserir(Fabricante f){dao.inserir(f);} public void alterar(Fabricante f){dao.alterar(f);} public void excluir(int i){dao.excluir(i);} public List<Fabricante> buscar(){return dao.buscar();}}
