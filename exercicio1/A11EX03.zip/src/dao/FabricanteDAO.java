package dao;
import model.Fabricante; import java.sql.*; import java.util.*;
public class FabricanteDAO {
 public void inserir(Fabricante f){executar("INSERT INTO Fabricante(nome) VALUES (?)",f.getNome(),null);}
 public void alterar(Fabricante f){executar("UPDATE Fabricante SET nome=? WHERE codigo=?",f.getNome(),f.getCodigo());}
 private void executar(String sql,String nome,Integer id){try(Connection c=Conexao.conectar();PreparedStatement p=c.prepareStatement(sql)){p.setString(1,nome);if(id!=null)p.setInt(2,id);p.executeUpdate();System.out.println("Operação realizada!");}catch(Exception e){System.out.println("Erro: "+e.getMessage());}}
 public void excluir(int id){try(Connection c=Conexao.conectar();PreparedStatement p=c.prepareStatement("DELETE FROM Fabricante WHERE codigo=?")){p.setInt(1,id);p.executeUpdate();System.out.println("Excluído!");}catch(Exception e){System.out.println("Erro: "+e.getMessage());}}
 public List<Fabricante> buscar(){List<Fabricante> l=new ArrayList<>();try(Connection c=Conexao.conectar();PreparedStatement p=c.prepareStatement("SELECT * FROM Fabricante");ResultSet r=p.executeQuery()){while(r.next())l.add(new Fabricante(r.getInt("codigo"),r.getString("nome")));}catch(Exception e){System.out.println("Erro: "+e.getMessage());}return l;}
}