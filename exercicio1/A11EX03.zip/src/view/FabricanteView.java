package view;
import controller.FabricanteController; import model.Fabricante; import java.util.*;
public class FabricanteView{
 public static void main(String[] a){Scanner s=new Scanner(System.in);FabricanteController c=new FabricanteController();int op;
 do{System.out.println("\n=== A11EX03 - FABRICANTE ===\n1-Cadastrar\n2-Listar\n3-Alterar\n4-Excluir\n0-Sair");op=s.nextInt();s.nextLine();
 switch(op){case 1:System.out.print("Nome: ");c.inserir(new Fabricante(s.nextLine()));break;case 2:c.buscar().forEach(System.out::println);break;case 3:System.out.print("Código: ");int id=s.nextInt();s.nextLine();System.out.print("Novo nome: ");c.alterar(new Fabricante(id,s.nextLine()));break;case 4:System.out.print("Código: ");c.excluir(s.nextInt());s.nextLine();break;}}while(op!=0);s.close();}
}