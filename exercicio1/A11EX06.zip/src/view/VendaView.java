package view;
import controller.VendaController;import model.Venda;import java.time.LocalDateTime;import java.util.*;
public class VendaView{
public static void main(String[]a){Scanner s=new Scanner(System.in);VendaController c=new VendaController();int op;
do{System.out.println("\n=== A11EX06 - VENDA ===\n1-Cadastrar venda\n2-Listar vendas\n3-Alterar venda\n4-Excluir venda\n0-Sair");op=s.nextInt();s.nextLine();
switch(op){case 1:System.out.print("Código vendedor: ");int v=s.nextInt();System.out.print("Código cliente: ");int cl=s.nextInt();s.nextLine();System.out.print("Código do produto (0 para nenhum): ");int prod=s.nextInt();s.nextLine();Venda venda=new Venda(0,LocalDateTime.now(),v,cl);if(prod!=0){model.Produto p=new model.Produto();p.setCodigo(prod);System.out.print("Valor unitário: ");p.setValor(s.nextDouble());s.nextLine();venda.getProdutos().add(p);}c.inserir(venda);break;
case 2:c.buscar().forEach(System.out::println);break;
case 3:System.out.print("Código da venda: ");int id=s.nextInt();System.out.print("Código vendedor: ");v=s.nextInt();System.out.print("Código cliente: ");cl=s.nextInt();s.nextLine();c.alterar(new Venda(id,LocalDateTime.now(),v,cl));break;
case 4:System.out.print("Código da venda: ");c.excluir(s.nextInt());s.nextLine();break;}}while(op!=0);s.close();}}
