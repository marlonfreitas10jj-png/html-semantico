package model;
import java.time.LocalDateTime;import java.util.*;
public class Venda{
private int codigo,vendedor,cliente;private LocalDateTime dataVenda;private List<Produto> produtos=new ArrayList<>();
public Venda(){} public Venda(int codigo,LocalDateTime dataVenda,int vendedor,int cliente){this.codigo=codigo;this.dataVenda=dataVenda;this.vendedor=vendedor;this.cliente=cliente;}
public int getCodigo(){return codigo;}public void setCodigo(int v){codigo=v;}public LocalDateTime getDataVenda(){return dataVenda;}public void setDataVenda(LocalDateTime v){dataVenda=v;}public int getVendedor(){return vendedor;}public void setVendedor(int v){vendedor=v;}public int getCliente(){return cliente;}public void setCliente(int v){cliente=v;}public List<Produto> getProdutos(){return produtos;}public void setProdutos(List<Produto> v){produtos=v;}
public String toString(){return "Venda "+codigo+" | Data: "+dataVenda+" | Vendedor: "+vendedor+" | Cliente: "+cliente+" | Produtos: "+produtos.size();}
}