package controller;
import dao.VendaDAO;import model.Venda;import java.util.List;
public class VendaController{private final VendaDAO dao=new VendaDAO();public int inserir(Venda v){return dao.inserir(v);}public void alterar(Venda v){dao.alterar(v);}public void excluir(int i){dao.excluir(i);}public List<Venda> buscar(){return dao.buscar();}}
