package controller;
import dao.PessoaDAO;
import model.Pessoa;
import java.util.List;

public class PessoaController {
    private final PessoaDAO dao=new PessoaDAO();
    public void inserir(Pessoa p){dao.inserir(p);}
    public void alterar(Pessoa p){dao.alterar(p);}
    public void excluir(int c){dao.excluir(c);}
    public List<Pessoa> buscar(){return dao.buscar();}
    public List<Pessoa> buscarPorCodigo(int c){return dao.buscarPorCodigo(c);}
    public List<Pessoa> buscarPorCpf(String cpf){return dao.buscarPorCpf(cpf);}
}