package view;
import controller.PessoaController;
import model.Pessoa;
import java.util.*;

public class PessoaView {
 public static void main(String[] args){
  Scanner s=new Scanner(System.in); PessoaController c=new PessoaController(); int op;
  do{
   System.out.println("\n=== A11EX02 - PESSOAS ===\n1-Cadastrar\n2-Listar\n3-Buscar código\n4-Buscar CPF\n5-Alterar\n6-Excluir\n0-Sair");
   op=s.nextInt(); s.nextLine();
   switch(op){
    case 1: System.out.print("Nome: ");String n=s.nextLine();System.out.print("CPF: ");String cpf=s.nextLine();c.inserir(new Pessoa(n,cpf));break;
    case 2: c.buscar().forEach(System.out::println);break;
    case 3: System.out.print("Código: ");c.buscarPorCodigo(s.nextInt()).forEach(System.out::println);s.nextLine();break;
    case 4: System.out.print("CPF: ");c.buscarPorCpf(s.nextLine()).forEach(System.out::println);break;
    case 5: System.out.print("Código: ");int id=s.nextInt();s.nextLine();System.out.print("Nome: ");n=s.nextLine();System.out.print("CPF: ");cpf=s.nextLine();c.alterar(new Pessoa(id,n,cpf));break;
    case 6: System.out.print("Código: ");c.excluir(s.nextInt());s.nextLine();break;
   }
  }while(op!=0); s.close();
 }
}