package dao;

import model.Pessoa;
import java.sql.*;
import java.util.*;

public class PessoaDAO {
    public void inserir(Pessoa p){
        String sql="INSERT INTO Pessoas(nome,cpf) VALUES (?,?)";
        try(Connection c=Conexao.conectar(); PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,p.getNome()); ps.setString(2,p.getCpf()); ps.executeUpdate();
            System.out.println("Pessoa cadastrada!");
        }catch(Exception e){System.out.println("Erro: "+e.getMessage());}
    }
    public void alterar(Pessoa p){
        String sql="UPDATE Pessoas SET nome=?, cpf=? WHERE codigo=?";
        try(Connection c=Conexao.conectar(); PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,p.getNome()); ps.setString(2,p.getCpf()); ps.setInt(3,p.getCodigo()); ps.executeUpdate();
            System.out.println("Pessoa alterada!");
        }catch(Exception e){System.out.println("Erro: "+e.getMessage());}
    }
    public void excluir(int codigo){
        try(Connection c=Conexao.conectar(); PreparedStatement ps=c.prepareStatement("DELETE FROM Pessoas WHERE codigo=?")){
            ps.setInt(1,codigo); ps.executeUpdate(); System.out.println("Pessoa excluída!");
        }catch(Exception e){System.out.println("Erro: "+e.getMessage());}
    }
    private List<Pessoa> executarBusca(String sql,Object valor){
        List<Pessoa> lista=new ArrayList<>();
        try(Connection c=Conexao.conectar(); PreparedStatement ps=c.prepareStatement(sql)){
            if(valor instanceof Integer) ps.setInt(1,(Integer)valor); else ps.setString(1,String.valueOf(valor));
            try(ResultSet rs=ps.executeQuery()){
                while(rs.next()) lista.add(new Pessoa(rs.getInt("codigo"),rs.getString("nome"),rs.getString("cpf")));
            }
        }catch(Exception e){System.out.println("Erro: "+e.getMessage());}
        return lista;
    }
    public List<Pessoa> buscar(){ 
        List<Pessoa> lista=new ArrayList<>();
        try(Connection c=Conexao.conectar(); PreparedStatement ps=c.prepareStatement("SELECT * FROM Pessoas"); ResultSet rs=ps.executeQuery()){
            while(rs.next()) lista.add(new Pessoa(rs.getInt("codigo"),rs.getString("nome"),rs.getString("cpf")));
        }catch(Exception e){System.out.println("Erro: "+e.getMessage());}
        return lista;
    }
    public List<Pessoa> buscarPorCodigo(int codigo){return executarBusca("SELECT * FROM Pessoas WHERE codigo=?",codigo);}
    public List<Pessoa> buscarPorCpf(String cpf){return executarBusca("SELECT * FROM Pessoas WHERE cpf=?",cpf);}
}