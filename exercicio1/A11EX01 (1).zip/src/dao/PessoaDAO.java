package dao;

import model.Pessoa;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PessoaDAO {

    public void inserir(Pessoa pessoa) {
        String sql = "INSERT INTO Pessoas (nome, cpf) VALUES (?, ?)";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement comando = conexao.prepareStatement(sql)) {

            comando.setString(1, pessoa.getNome());
            comando.setString(2, pessoa.getCpf());
            comando.executeUpdate();

            System.out.println("Pessoa cadastrada com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao inserir pessoa: " + e.getMessage());
        }
    }

    public void alterar(Pessoa pessoa) {
        String sql = "UPDATE Pessoas SET nome = ?, cpf = ? WHERE codigo = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement comando = conexao.prepareStatement(sql)) {

            comando.setString(1, pessoa.getNome());
            comando.setString(2, pessoa.getCpf());
            comando.setInt(3, pessoa.getCodigo());
            comando.executeUpdate();

            System.out.println("Pessoa alterada com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao alterar pessoa: " + e.getMessage());
        }
    }

    public void excluir(int codigo) {
        String sql = "DELETE FROM Pessoas WHERE codigo = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement comando = conexao.prepareStatement(sql)) {

            comando.setInt(1, codigo);
            comando.executeUpdate();

            System.out.println("Pessoa excluída com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao excluir pessoa: " + e.getMessage());
        }
    }

    public List<Pessoa> buscar() {
        List<Pessoa> pessoas = new ArrayList<>();
        String sql = "SELECT * FROM Pessoas";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement comando = conexao.prepareStatement(sql);
             ResultSet resultado = comando.executeQuery()) {

            while (resultado.next()) {
                Pessoa pessoa = new Pessoa();
                pessoa.setCodigo(resultado.getInt("codigo"));
                pessoa.setNome(resultado.getString("nome"));
                pessoa.setCpf(resultado.getString("cpf"));
                pessoas.add(pessoa);
            }

        } catch (Exception e) {
            System.out.println("Erro ao buscar pessoas: " + e.getMessage());
        }

        return pessoas;
    }
}
