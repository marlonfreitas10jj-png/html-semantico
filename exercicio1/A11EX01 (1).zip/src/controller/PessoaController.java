package controller;

import dao.PessoaDAO;
import model.Pessoa;
import java.util.List;

public class PessoaController {

    private PessoaDAO pessoaDAO;

    public PessoaController() {
        pessoaDAO = new PessoaDAO();
    }

    public void inserir(Pessoa pessoa) {
        pessoaDAO.inserir(pessoa);
    }

    public void alterar(Pessoa pessoa) {
        pessoaDAO.alterar(pessoa);
    }

    public void excluir(int codigo) {
        pessoaDAO.excluir(codigo);
    }

    public List<Pessoa> buscar() {
        return pessoaDAO.buscar();
    }
}
