package view;

import controller.PessoaController;
import model.Pessoa;
import java.util.List;
import java.util.Scanner;

public class PessoaView {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        PessoaController controller = new PessoaController();
        int opcao;

        do {
            System.out.println("\n===== SISTEMA LOJA =====");
            System.out.println("===== CRUD DE PESSOAS =====");
            System.out.println("1 - Cadastrar pessoa");
            System.out.println("2 - Listar pessoas");
            System.out.println("3 - Alterar pessoa");
            System.out.println("4 - Excluir pessoa");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");

            opcao = entrada.nextInt();
            entrada.nextLine();

            switch (opcao) {
                case 1:
                    System.out.println("\n--- CADASTRAR PESSOA ---");
                    System.out.print("Nome: ");
                    String nome = entrada.nextLine();
                    System.out.print("CPF: ");
                    String cpf = entrada.nextLine();
                    controller.inserir(new Pessoa(nome, cpf));
                    break;

                case 2:
                    System.out.println("\n--- LISTA DE PESSOAS ---");
                    List<Pessoa> pessoas = controller.buscar();

                    if (pessoas.isEmpty()) {
                        System.out.println("Nenhuma pessoa cadastrada.");
                    } else {
                        for (Pessoa pessoa : pessoas) {
                            System.out.println(pessoa);
                        }
                    }
                    break;

                case 3:
                    System.out.println("\n--- ALTERAR PESSOA ---");
                    System.out.print("Código da pessoa: ");
                    int codigoAlterar = entrada.nextInt();
                    entrada.nextLine();
                    System.out.print("Novo nome: ");
                    String novoNome = entrada.nextLine();
                    System.out.print("Novo CPF: ");
                    String novoCpf = entrada.nextLine();

                    controller.alterar(
                        new Pessoa(codigoAlterar, novoNome, novoCpf)
                    );
                    break;

                case 4:
                    System.out.println("\n--- EXCLUIR PESSOA ---");
                    System.out.print("Código da pessoa: ");
                    int codigoExcluir = entrada.nextInt();
                    controller.excluir(codigoExcluir);
                    break;

                case 0:
                    System.out.println("Sistema encerrado.");
                    break;

                default:
                    System.out.println("Opção inválida!");
            }

        } while (opcao != 0);

        entrada.close();
    }
}
