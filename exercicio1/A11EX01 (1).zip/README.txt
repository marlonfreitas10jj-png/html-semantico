A11EX01 - CRUD de Pessoas
Projeto Java + MySQL usando MVC + DAO.

Banco: Loja
Tabela: Pessoas

Antes de executar:
1. Crie o banco usando o arquivo banco.sql.
2. Adicione o MySQL Connector/J ao projeto no NetBeans.
3. Confira usuário e senha do MySQL em dao/Conexao.java.
4. Abra o projeto no NetBeans e execute view/PessoaView.java.
