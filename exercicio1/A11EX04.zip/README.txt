A11EX04 - CRUD de Vendedor com herança de Pessoa

Projeto Java + MySQL usando MVC + DAO.

1. Abra a pasta A11EX04 no NetBeans.
2. Adicione o MySQL Connector/J em Libraries.
3. O projeto espera o JAR em lib/mysql-connector-j.jar se você preferir usar a propriedade já configurada.
4. Execute a classe view.VendedorView.
5. Antes, execute banco.sql no MySQL.
6. Confira usuário e senha em dao/Conexao.java.
