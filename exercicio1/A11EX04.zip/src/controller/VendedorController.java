package controller;
import dao.VendedorDAO;import model.Vendedor;import java.util.List;
public class VendedorController{private final VendedorDAO dao=new VendedorDAO();public void inserir(Vendedor v){dao.inserir(v);}public void alterar(Vendedor v){dao.alterar(v);}public void excluir(int i){dao.excluir(i);}public List<Vendedor> buscar(){return dao.buscar();}}
