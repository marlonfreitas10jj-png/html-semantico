package view;
import controller.VendedorController;import model.Vendedor;import java.util.*;
public class VendedorView{
public static void main(String[]a){Scanner s=new Scanner(System.in);VendedorController c=new VendedorController();int op;
do{System.out.println("\n=== A11EX04 - VENDEDOR ===\n1-Cadastrar\n2-Listar\n3-Alterar\n4-Excluir\n0-Sair");op=s.nextInt();s.nextLine();
switch(op){case 1:System.out.print("Nome: ");String n=s.nextLine();System.out.print("CPF: ");String cpf=s.nextLine();System.out.print("Login: ");String l=s.nextLine();System.out.print("Senha: ");String sen=s.nextLine();System.out.print("Foto: ");String f=s.nextLine();c.inserir(new Vendedor(0,n,cpf,l,sen,f,null));break;
case 2:c.buscar().forEach(System.out::println);break;
case 3:System.out.print("Código: ");int id=s.nextInt();s.nextLine();System.out.print("Nome: ");n=s.nextLine();System.out.print("CPF: ");cpf=s.nextLine();System.out.print("Login: ");l=s.nextLine();System.out.print("Senha: ");sen=s.nextLine();System.out.print("Foto: ");f=s.nextLine();c.alterar(new Vendedor(id,n,cpf,l,sen,f,null));break;
case 4:System.out.print("Código: ");c.excluir(s.nextInt());s.nextLine();break;}}while(op!=0);s.close();}}
