package model;
import java.time.LocalDateTime;
public class Vendedor extends Pessoa {
 private String login,senha,foto; private LocalDateTime ultimoLogin;
 public Vendedor(){} public Vendedor(int codigo,String nome,String cpf,String login,String senha,String foto,LocalDateTime ultimoLogin){super(codigo,nome,cpf);this.login=login;this.senha=senha;this.foto=foto;this.ultimoLogin=ultimoLogin;}
 public String getLogin(){return login;}public void setLogin(String v){login=v;}public String getSenha(){return senha;}public void setSenha(String v){senha=v;}public String getFoto(){return foto;}public void setFoto(String v){foto=v;}public LocalDateTime getUltimoLogin(){return ultimoLogin;}public void setUltimoLogin(LocalDateTime v){ultimoLogin=v;}
 public String toString(){return "Código: "+getCodigo()+" | Nome: "+getNome()+" | CPF: "+getCpf()+" | Login: "+login+" | Foto: "+foto+" | Último login: "+ultimoLogin;}
}