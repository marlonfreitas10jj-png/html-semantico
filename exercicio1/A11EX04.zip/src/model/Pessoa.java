package model;
public class Pessoa {private int codigo;private String nome;private String cpf;
public Pessoa(){} public Pessoa(int codigo,String nome,String cpf){this.codigo=codigo;this.nome=nome;this.cpf=cpf;}
public int getCodigo(){return codigo;}public void setCodigo(int v){codigo=v;}public String getNome(){return nome;}public void setNome(String v){nome=v;}public String getCpf(){return cpf;}public void setCpf(String v){cpf=v;}}
